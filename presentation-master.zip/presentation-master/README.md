Presentation Template
=====================

A presentation template by Chris Kankiewicz ([@PHLAK](https://twitter.com/PHLAK))

Built with [reveal.js](https://revealjs.com/) and [Tailwind CSS](https://tailwindcss.com/)

Development
-----------

    npm install && npm run dev
