<script>
 export let trim;
 export let noescape;
 export let lineNumbers;
 export let lineStartFrom;
</script>
<pre>
		<code data-trim={trim} data-noescape={noescape} data-line-numbers={lineNumbers} data-ln-start-from={lineStartFrom}>
				<slot/>
		</code>
</pre>
