<section>
  <h2>Barebones Presentation</h2>
  <p>This example contains the bare minimum includes and markup required to run a reveal.js presentation.</p>
</section>

<section>
  <h2>No Theme</h2>
  <p>There's no theme included, so it will fall back on browser defaults.</p>
</section>

