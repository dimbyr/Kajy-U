<section data-background="#00ffff">
  <h2>data-background: #00ffff</h2>
</section>

<section data-background="#bb00bb">
  <h2>data-background: #bb00bb</h2>
</section>

<section data-background-color="lightblue">
  <h2>data-background: lightblue</h2>
</section>

<section>
  <section data-background="#ff0000">
    <h2>data-background: #ff0000</h2>
  </section>
  <section data-background="rgba(0, 0, 0, 0.2)">
    <h2>data-background: rgba(0, 0, 0, 0.2)</h2>
  </section>
  <section data-background="salmon">
    <h2>data-background: salmon</h2>
  </section>
</section>

<section data-background="rgba(0, 100, 100, 0.2)">
  <section>
    <h2>Background applied to stack</h2>
  </section>
  <section>
    <h2>Background applied to stack</h2>
  </section>
  <section data-background="rgb(66, 66, 66)">
    <h2>Background applied to slide inside of stack</h2>
  </section>
</section>

<section data-background-transition="slide" data-background="assets/image1.png">
  <h2>Background image</h2>
</section>

<section>
  <section data-background-transition="slide" data-background="assets/image1.png">
    <h2>Background image</h2>
  </section>
  <section data-background-transition="slide" data-background="assets/image1.png">
    <h2>Background image</h2>
  </section>
</section>

<section data-background="assets/image2.png" data-background-size="100px" data-background-repeat="repeat" data-background-color="#111">
  <h2>Background image</h2>
  <pre>data-background-size="100px" data-background-repeat="repeat" data-background-color="#111"</pre>
</section>

<section data-background="#888888">
  <h2>Same background twice (1/2)</h2>
</section>
<section data-background="#888888">
  <h2>Same background twice (2/2)</h2>
</section>

<section data-background-video="https://s3.amazonaws.com/static.slid.es/site/homepage/v1/homepage-video-editor.mp4,https://s3.amazonaws.com/static.slid.es/site/homepage/v1/homepage-video-editor.webm">
  <h2>Video background</h2>
</section>

<section data-background-iframe="https://slides.com/news/make-better-presentations/embed?style=hidden&autoSlide=4000">
  <h2>Iframe background</h2>
</section>

<section>
  <section data-background="#417203">
    <h2>Same background twice vertical (1/2)</h2>
  </section>
  <section data-background="#417203">
    <h2>Same background twice vertical (2/2)</h2>
  </section>
</section>

<section data-background="#934f4d">
  <h2>Same background from horizontal to vertical (1/3)</h2>
</section>
<section>
  <section data-background="#934f4d">
    <h2>Same background from horizontal to vertical (2/3)</h2>
  </section>
  <section data-background="#934f4d">
    <h2>Same background from horizontal to vertical (3/3)</h2>
  </section>
</section>

  <style>
  .slides section.has-dark-background,
  .slides section.has-dark-background h2 {
    color: #fff;
  }
  .slides section.has-light-background,
  .slides section.has-light-background h2 {
    color: #222;
  }
</style>


