<section>
  <h3>Default</h3>
</section>

<section>
  <h3>Default</h3>
</section>

<section data-transition="zoom">
  <h3>data-transition: zoom</h3>
</section>

<section data-transition="zoom-in fade-out">
  <h3>data-transition: zoom-in fade-out</h3>
</section>

<section>
  <h3>Default</h3>
</section>

<section data-transition="convex">
  <h3>data-transition: convex</h3>
</section>

<section data-transition="convex-in concave-out">
  <h3>data-transition: convex-in concave-out</h3>
</section>

<section>
  <section data-transition="zoom">
    <h3>Default</h3>
  </section>
  <section data-transition="concave">
    <h3>data-transition: concave</h3>
  </section>
  <section data-transition="convex-in fade-out">
    <h3>data-transition: convex-in fade-out</h3>
  </section>
  <section>
    <h3>Default</h3>
  </section>
</section>

<section data-transition="none">
  <h3>data-transition: none</h3>
</section>

<section>
  <h3>Default</h3>
</section>

<style >
  .slides section.has-dark-background,
  .slides section.has-dark-background h3 {
    color: #fff;
  }
  .slides section.has-light-background,
  .slides section.has-light-background h3 {
    color: #222;
  }
</style>
